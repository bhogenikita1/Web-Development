import '../styles/footer.css'
function Footer() {
    return (
        <>
            <footer className="footer">
                <p> &copy;2024 Restaurant Name. All Rights Reserved.</p>
            </footer>
        </>
    )
}
export default Footer;